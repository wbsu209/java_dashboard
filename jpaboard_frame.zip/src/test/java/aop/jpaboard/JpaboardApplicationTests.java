package aop.jpaboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
